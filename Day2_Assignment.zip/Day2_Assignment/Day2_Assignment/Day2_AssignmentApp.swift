//
//  Day2_AssignmentApp.swift
//  Day2_Assignment
//
//  Created by Taibah Valley Academy on 04/09/1446 AH.
//

import SwiftUI

@main
struct Day2_AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
