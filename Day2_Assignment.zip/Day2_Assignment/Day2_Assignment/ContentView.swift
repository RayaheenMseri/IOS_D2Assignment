//
//  ContentView.swift
//  ClassTask1
//
//  Created by Taibah Valley Academy on 3/4/25.
//

import SwiftUI

struct ContentView: View {
    
    @State var names = ["Rayaheen", "Raneem", "Areen"]
    @State var searchText: String = ""
    @State var isSorted = true
    @State var isUppercase = false
    
    var body: some View {
        NavigationStack {
            List(searchResults, id: \.self){
                name in Text(name)
            }.navigationTitle("Family Names")
        }.searchable(text: $searchText)
        
        Button(isSorted ? "Sort" : "Shuffle"){
            isSorted.toggle()
            names = isSorted ? names.sorted() : names.shuffled()
        }
        .padding()
        
        Button(isUppercase ? "Switch to Lowercase" : "Switch to Uppercase") {
            isUppercase.toggle()
            names = changeCase
        }
        .padding()
    }
    
    var searchResults: [String]{
        if searchText.isEmpty {
            return names
        }else {
            return names.filter{$0.contains(searchText)}
        }
    }
    
    var changeCase: [String] {
        isUppercase ? names.map { $0.uppercased() } : names.map { $0.lowercased() }
    }
}

#Preview {
    ContentView()
}
